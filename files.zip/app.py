"""Flask entry point for the image classifier.

Run in development:
    python app.py

Run in production (Windows):
    waitress-serve --host=0.0.0.0 --port=8000 "app:create_app()"

Run in production (Linux/macOS):
    gunicorn --workers 2 --threads 4 --timeout 120 "app:create_app()"
"""

from __future__ import annotations

import logging
import os
import uuid
from pathlib import Path
from typing import Any

from flask import Flask, jsonify, render_template, request
from werkzeug.exceptions import HTTPException, RequestEntityTooLarge
from werkzeug.utils import secure_filename

from config import Config, get_config
from ml.model import ModelLoadError, get_model
from ml.predict import classify
from utils.validators import InvalidImageError, read_upload

log = logging.getLogger(__name__)


def _configure_logging(level: str) -> None:
    logging.basicConfig(
        level=getattr(logging, level, logging.INFO),
        format="%(asctime)s %(levelname)-7s %(name)s | %(message)s",
        datefmt="%H:%M:%S",
    )
    # TensorFlow is extremely chatty on import; keep the console readable.
    os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")


def _wants_json() -> bool:
    return request.path.startswith("/api/") or request.accept_mimetypes.best == "application/json"


def _error(message: str, status: int, code: str) -> Any:
    """Return JSON for API callers, a rendered page for browsers."""
    if _wants_json():
        response = jsonify({"ok": False, "error": {"code": code, "message": message}})
        response.status_code = status
        return response

    template = "404.html" if status == 404 else "500.html"
    return render_template(template, message=message), status


def _persist(payload: bytes, filename: str, folder: Path) -> str | None:
    """Optionally keep a copy of the upload. Returns the stored name."""
    folder.mkdir(parents=True, exist_ok=True)
    safe = secure_filename(filename) or "upload.jpg"
    stored = f"{uuid.uuid4().hex}_{safe}"
    (folder / stored).write_bytes(payload)
    return stored


def create_app(config_name: str | None = None) -> Flask:
    config: type[Config] = get_config(config_name)
    _configure_logging(config.LOG_LEVEL)

    app = Flask(__name__, static_folder="static", template_folder="templates")
    app.config.from_object(config)

    config.UPLOAD_FOLDER.mkdir(parents=True, exist_ok=True)
    config.MODEL_DIR.mkdir(parents=True, exist_ok=True)

    if config.PRELOAD_MODEL:
        try:
            get_model(config)
        except ModelLoadError as exc:
            log.error("Preload failed, will retry on first request: %s", exc)

    # -- security headers --------------------------------------------------
    @app.after_request
    def add_security_headers(response):  # type: ignore[no-untyped-def]
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "same-origin")
        return response

    # -- pages -------------------------------------------------------------
    @app.get("/")
    def index():  # type: ignore[no-untyped-def]
        return render_template(
            "index.html",
            max_upload_mb=config.MAX_UPLOAD_MB,
            top_k=config.TOP_K,
            accept=",".join(f".{e}" for e in sorted(config.ALLOWED_EXTENSIONS)),
        )

    # -- api ---------------------------------------------------------------
    @app.get("/api/health")
    def health():  # type: ignore[no-untyped-def]
        return jsonify({"ok": True, "status": "up"})

    @app.get("/api/model")
    def model_info():  # type: ignore[no-untyped-def]
        bundle = get_model(config)
        return jsonify({"ok": True, "model": bundle.describe()})

    @app.post("/api/predict")
    def predict():  # type: ignore[no-untyped-def]
        file_storage = request.files.get("image")
        payload = read_upload(
            file_storage,
            allowed_extensions=config.ALLOWED_EXTENSIONS,
            max_bytes=config.MAX_CONTENT_LENGTH,
        )

        result = classify(payload, config)

        if config.KEEP_UPLOADS and file_storage is not None:
            result["image"]["stored_as"] = _persist(
                payload, file_storage.filename or "upload.jpg", config.UPLOAD_FOLDER
            )

        return jsonify({"ok": True, **result})

    # -- errors ------------------------------------------------------------
    @app.errorhandler(InvalidImageError)
    def handle_invalid_image(exc: InvalidImageError):  # type: ignore[no-untyped-def]
        return _error(str(exc), 400, "invalid_image")

    @app.errorhandler(RequestEntityTooLarge)
    def handle_too_large(_exc: RequestEntityTooLarge):  # type: ignore[no-untyped-def]
        return _error(
            f"The file is larger than {config.MAX_UPLOAD_MB} MB.", 413, "file_too_large"
        )

    @app.errorhandler(ModelLoadError)
    def handle_model_error(exc: ModelLoadError):  # type: ignore[no-untyped-def]
        log.exception("Model unavailable")
        return _error(str(exc), 503, "model_unavailable")

    @app.errorhandler(404)
    def handle_not_found(_exc):  # type: ignore[no-untyped-def]
        return _error("That page does not exist.", 404, "not_found")

    @app.errorhandler(HTTPException)
    def handle_http_exception(exc: HTTPException):  # type: ignore[no-untyped-def]
        return _error(exc.description or exc.name, exc.code or 500, "http_error")

    @app.errorhandler(Exception)
    def handle_unexpected(exc: Exception):  # type: ignore[no-untyped-def]
        log.exception("Unhandled error: %s", exc)
        return _error("Something failed on the server. Check the console log.", 500, "server_error")

    return app


app = create_app()


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    # use_reloader is off because it would load the model twice.
    app.run(host="127.0.0.1", port=port, debug=app.config["DEBUG"], use_reloader=False)
