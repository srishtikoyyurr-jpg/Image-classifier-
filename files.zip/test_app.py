"""Tests for the routes, validators and preprocessing.

A fake model is injected so the suite never imports TensorFlow. It runs in
about a second, which is the only way tests get run at all.
"""

from __future__ import annotations

import io

import numpy as np
import pytest
from PIL import Image

from app import create_app
from ml import model as model_module
from ml.model import ModelBundle
from ml.preprocess import apply_mode, open_image, resize_and_center_crop
from utils.validators import InvalidImageError, has_allowed_extension, looks_like_image


class FakeKerasModel:
    """Returns a deterministic distribution over three classes."""

    input_shape = (None, 224, 224, 3)

    def predict(self, batch, verbose=0):  # noqa: ARG002
        assert batch.shape == (1, 224, 224, 3), batch.shape
        return np.array([[0.70, 0.25, 0.05]], dtype=np.float32)


@pytest.fixture()
def app():
    application = create_app("testing")
    model_module.set_model(
        ModelBundle(
            name="fake",
            source="custom",
            input_size=(224, 224),
            preprocess_mode="rescale",
            keras_model=FakeKerasModel(),
            labels=["cat", "dog", "bird"],
        )
    )
    yield application
    model_module.set_model(None)


@pytest.fixture()
def client(app):
    return app.test_client()


def make_image(fmt: str = "JPEG", size=(320, 240), color=(200, 40, 40)) -> bytes:
    buffer = io.BytesIO()
    Image.new("RGB", size, color).save(buffer, format=fmt)
    return buffer.getvalue()


def upload(client, data: bytes, filename: str = "photo.jpg"):
    return client.post(
        "/api/predict",
        data={"image": (io.BytesIO(data), filename)},
        content_type="multipart/form-data",
    )


# --- pages ------------------------------------------------------------------
def test_index_renders(client):
    response = client.get("/")
    assert response.status_code == 200
    assert b"What is in this picture?" in response.data


def test_health(client):
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.get_json() == {"ok": True, "status": "up"}


def test_unknown_page_returns_404(client):
    response = client.get("/nope")
    assert response.status_code == 404


def test_model_info(client):
    payload = client.get("/api/model").get_json()
    assert payload["ok"] is True
    assert payload["model"]["classes"] == 3
    assert payload["model"]["input_shape"] == [224, 224, 3]


# --- happy path -------------------------------------------------------------
def test_predict_returns_ranked_classes(client):
    payload = upload(client, make_image()).get_json()

    assert payload["ok"] is True
    assert payload["top"] == {"label": "cat", "confidence": 0.7}
    assert [p["label"] for p in payload["predictions"]] == ["cat", "dog", "bird"]

    confidences = [p["confidence"] for p in payload["predictions"]]
    assert confidences == sorted(confidences, reverse=True)
    assert payload["timing"]["total_ms"] >= 0
    assert payload["image"]["original_size"] == [320, 240]


def test_predict_accepts_png_and_webp(client):
    for fmt, name in (("PNG", "a.png"), ("WEBP", "a.webp")):
        response = upload(client, make_image(fmt), name)
        assert response.status_code == 200, name


# --- failure paths ----------------------------------------------------------
def test_missing_file_is_rejected(client):
    response = client.post("/api/predict", data={}, content_type="multipart/form-data")
    body = response.get_json()
    assert response.status_code == 400
    assert body["error"]["code"] == "invalid_image"


def test_wrong_extension_is_rejected(client):
    response = upload(client, make_image(), "notes.txt")
    assert response.status_code == 400
    assert "Unsupported file type" in response.get_json()["error"]["message"]


def test_disguised_file_is_rejected(client):
    """A text file renamed to .jpg must not reach the model."""
    response = upload(client, b"this is definitely not an image", "trick.jpg")
    assert response.status_code == 400
    assert response.get_json()["error"]["code"] == "invalid_image"


def test_empty_file_is_rejected(client):
    response = upload(client, b"", "empty.jpg")
    assert response.status_code == 400


def test_oversized_file_is_rejected(app):
    app.config["MAX_CONTENT_LENGTH"] = 1024
    response = app.test_client().post(
        "/api/predict",
        data={"image": (io.BytesIO(make_image(size=(900, 900))), "big.jpg")},
        content_type="multipart/form-data",
    )
    assert response.status_code == 413


# --- units ------------------------------------------------------------------
def test_extension_check():
    allowed = {"jpg", "png"}
    assert has_allowed_extension("a.JPG", allowed)
    assert not has_allowed_extension("a.gif", allowed)
    assert not has_allowed_extension("noextension", allowed)


def test_magic_byte_check():
    assert looks_like_image(make_image("PNG"))
    assert not looks_like_image(b"PK\x03\x04 zip archive")


def test_open_image_flattens_transparency():
    buffer = io.BytesIO()
    Image.new("RGBA", (10, 10), (255, 0, 0, 0)).save(buffer, format="PNG")
    image = open_image(buffer.getvalue())
    assert image.mode == "RGB"
    assert image.getpixel((0, 0)) == (255, 255, 255)  # composited onto white


def test_open_image_rejects_garbage():
    with pytest.raises(InvalidImageError):
        open_image(b"not an image at all")


def test_center_crop_preserves_aspect_ratio():
    source = Image.new("RGB", (400, 200))
    cropped = resize_and_center_crop(source, (224, 224))
    assert cropped.size == (224, 224)


def test_preprocess_modes():
    pixels = np.array([[0, 255]], dtype=np.uint8)
    assert apply_mode(pixels, "rescale").tolist() == [[0.0, 1.0]]
    assert apply_mode(pixels, "mobilenet_v2").tolist() == [[-1.0, 1.0]]
    with pytest.raises(ValueError):
        apply_mode(pixels, "nonsense")


def test_logits_are_softmaxed():
    class LogitModel(FakeKerasModel):
        def predict(self, batch, verbose=0):  # noqa: ARG002
            return np.array([[2.0, 1.0, -3.0]], dtype=np.float32)

    bundle = ModelBundle(
        name="logits", source="custom", input_size=(224, 224),
        preprocess_mode="rescale", keras_model=LogitModel(), labels=["a", "b", "c"],
    )
    probs = bundle.predict(np.zeros((1, 224, 224, 3), dtype=np.float32))
    assert probs.min() >= 0
    assert pytest.approx(float(probs.sum()), abs=1e-5) == 1.0
