"""Turn raw upload bytes into the exact tensor the model was trained on.

Deliberately free of any TensorFlow import: preprocessing is pure NumPy +
Pillow, so it can be unit tested in milliseconds and reused by a PyTorch
backend without changes.
"""

from __future__ import annotations

import io

import numpy as np
from PIL import Image, ImageOps, UnidentifiedImageError

from utils.validators import InvalidImageError

# Refuse decompression bombs: 40 megapixels is far beyond any real photo.
Image.MAX_IMAGE_PIXELS = 40_000_000

# How pixel values are mapped before they reach the network.
PREPROCESS_MODES = ("mobilenet_v2", "rescale", "raw")


def open_image(payload: bytes) -> Image.Image:
    """Decode `payload` into an upright RGB image.

    Pillow's `verify()` is a structural check that consumes the file object,
    so the image is opened a second time for real decoding.
    """
    try:
        Image.open(io.BytesIO(payload)).verify()
    except Image.DecompressionBombError as exc:
        raise InvalidImageError("The image is too large to process.") from exc
    except (UnidentifiedImageError, OSError, ValueError) as exc:
        raise InvalidImageError("The image is corrupt and cannot be read.") from exc

    try:
        image = Image.open(io.BytesIO(payload))
        image.load()
    except (UnidentifiedImageError, OSError) as exc:
        raise InvalidImageError("The image is corrupt and cannot be read.") from exc

    # Phones store rotation in EXIF rather than in the pixels.
    image = ImageOps.exif_transpose(image)

    if image.mode != "RGB":
        # Flatten transparency onto white so PNGs and GIFs do not arrive black.
        if image.mode in {"RGBA", "LA", "P"}:
            image = image.convert("RGBA")
            canvas = Image.new("RGBA", image.size, (255, 255, 255, 255))
            image = Image.alpha_composite(canvas, image)
        image = image.convert("RGB")

    return image


def resize_and_center_crop(image: Image.Image, size: tuple[int, int]) -> Image.Image:
    """Scale the short side to fit, then crop the centre.

    Squashing a 16:9 photo into a square distorts every object in it and
    measurably lowers accuracy, so aspect ratio is preserved instead.
    """
    target_w, target_h = size
    src_w, src_h = image.size
    scale = max(target_w / src_w, target_h / src_h)
    new_w, new_h = max(1, round(src_w * scale)), max(1, round(src_h * scale))

    image = image.resize((new_w, new_h), Image.Resampling.BILINEAR)

    left = (new_w - target_w) // 2
    top = (new_h - target_h) // 2
    return image.crop((left, top, left + target_w, top + target_h))


def apply_mode(array: np.ndarray, mode: str) -> np.ndarray:
    """Map uint8 pixels into the value range the network expects."""
    array = array.astype(np.float32)
    if mode == "mobilenet_v2":
        # Keras `mobilenet_v2.preprocess_input`, inlined: scale to [-1, 1].
        return array / 127.5 - 1.0
    if mode == "rescale":
        return array / 255.0
    if mode == "raw":
        return array
    raise ValueError(f"Unknown preprocess mode: {mode!r}. Use one of {PREPROCESS_MODES}.")


def to_batch(image: Image.Image, size: tuple[int, int], mode: str) -> np.ndarray:
    """Produce a float32 tensor of shape (1, H, W, 3)."""
    cropped = resize_and_center_crop(image, size)
    array = np.asarray(cropped, dtype=np.uint8)
    array = apply_mode(array, mode)
    return np.expand_dims(array, axis=0)


def preprocess_bytes(payload: bytes, size: tuple[int, int], mode: str) -> np.ndarray:
    """Convenience wrapper: bytes in, model-ready batch out."""
    return to_batch(open_image(payload), size, mode)
