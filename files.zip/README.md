# Image Classifier

Upload an image, get back a probability distribution over the model's classes.

Flask on the back, plain HTML/CSS/JS on the front, TensorFlow/Keras in the
middle. It ships working out of the box: with no trained model on disk it loads
**MobileNetV2** with ImageNet weights and classifies 1,000 everyday categories.
Drop your own `models/model.keras` in and it uses that instead.

---

## Why it is built this way

| Decision | Reason |
|---|---|
| Model loaded once behind a lock | Keras graphs are not thread-safe to load, and a 14 MB model per request would be fatal |
| Preprocessing has no TensorFlow import | Tests run in a second, and the module ports to PyTorch unchanged |
| Resize + centre crop, not squash | Distorting aspect ratio measurably lowers accuracy |
| Magic-byte check after extension check | `payload.exe` renamed to `cat.jpg` never reaches the model |
| Uploads processed in memory | Nothing to clean up, nothing to leak. Set `KEEP_UPLOADS=1` if you want copies |
| Softmax applied when the output is not a distribution | Works with models whose last layer emits logits |
| `waitress` not `gunicorn` for production | `gunicorn` does not run on Windows |

---

## Project structure

```
image-classifier/
├── app.py                      Flask app factory, routes, error handlers
├── config.py                   Environment-driven configuration
├── requirements.txt            Runtime dependencies (pinned)
├── requirements-dev.txt        Adds pytest
├── pytest.ini                  Test configuration
├── .env.example                Copy to .env and edit
├── .gitignore
├── README.md
│
├── ml/
│   ├── __init__.py
│   ├── model.py                Lazy, thread-safe model loading + decoding
│   ├── preprocess.py           Decode, EXIF-rotate, crop, normalise
│   └── predict.py              Orchestrates one inference, returns JSON
│
├── utils/
│   ├── __init__.py
│   └── validators.py           Extension, size and magic-byte checks
│
├── templates/
│   ├── base.html               Shared chrome
│   ├── index.html              Upload panel + readout panel
│   ├── 404.html
│   └── 500.html
│
├── static/
│   ├── css/style.css           The whole visual system
│   └── js/main.js              The whole client
│
├── scripts/
│   └── train_custom_model.py   Transfer learning on your own folders
│
├── tests/
│   ├── __init__.py
│   └── test_app.py             18 tests, no TensorFlow needed
│
├── models/                     model.keras, labels.txt, model.meta.json
├── uploads/                    Only used when KEEP_UPLOADS=1
└── .vscode/
    ├── settings.json
    └── launch.json             F5 to debug
```

---

## Requirements

- **Python 3.10, 3.11 or 3.12.** TensorFlow 2.19 has no wheel for 3.13.
  Check with `python --version`.
- About 1.5 GB of disk for TensorFlow and its dependencies.
- An internet connection on the **first run only**, to download the MobileNetV2
  weights (~14 MB) into `~/.keras/models/`. After that it runs offline.

---

## Setup

### Windows — PowerShell

```powershell
cd image-classifier

python -m venv venv
.\venv\Scripts\Activate.ps1

python -m pip install --upgrade pip
pip install -r requirements.txt

python app.py
```

If PowerShell blocks the activation script, run this once for the current user:

```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### Windows — Command Prompt (cmd.exe)

```cmd
cd image-classifier

python -m venv venv
venv\Scripts\activate.bat

python -m pip install --upgrade pip
pip install -r requirements.txt

python app.py
```

### macOS / Linux

```bash
cd image-classifier

python3 -m venv venv
source venv/bin/activate

python -m pip install --upgrade pip
pip install -r requirements.txt

python app.py
```

Then open <http://127.0.0.1:5000>.

---

## Expected output

```
16:04:12 INFO    __main__ | Model ready: {'name': 'MobileNetV2', 'source': 'imagenet', ...}
 * Serving Flask app 'app'
 * Debug mode: on
 * Running on http://127.0.0.1:5000
Press CTRL+C to quit
```

The first upload takes a few seconds while Keras downloads weights and builds
the graph. Every upload after that is roughly 50–200 ms of inference on CPU.

A successful `POST /api/predict` returns:

```json
{
  "ok": true,
  "top": { "label": "golden retriever", "confidence": 0.8123 },
  "predictions": [
    { "label": "golden retriever", "confidence": 0.8123 },
    { "label": "labrador retriever", "confidence": 0.0914 },
    { "label": "kuvasz", "confidence": 0.0231 },
    { "label": "clumber", "confidence": 0.0107 },
    { "label": "tennis ball", "confidence": 0.0052 }
  ],
  "model": {
    "name": "MobileNetV2", "source": "imagenet",
    "input_shape": [224, 224, 3], "classes": 1000, "preprocess": "mobilenet_v2"
  },
  "timing": { "preprocess_ms": 12.4, "inference_ms": 68.9, "total_ms": 81.3 },
  "image": { "original_size": [1600, 1200] }
}
```

Failures return HTTP 400/413/503 with the same envelope:

```json
{ "ok": false, "error": { "code": "invalid_image", "message": "The file is empty." } }
```

---

## API

| Method | Path | Purpose |
|---|---|---|
| `GET` | `/` | The page |
| `GET` | `/api/health` | Liveness probe, never touches the model |
| `GET` | `/api/model` | Name, input shape, class count |
| `POST` | `/api/predict` | `multipart/form-data` with field `image` |

```bash
curl -F "image=@dog.jpg" http://127.0.0.1:5000/api/predict
```

---

## Testing

```bash
pip install -r requirements-dev.txt
pytest
```

Expect `18 passed`. The suite injects a fake model, so it does not import
TensorFlow and finishes in about a second.

### Manual checks

1. **Happy path** — upload a JPG of an animal. A label, a confidence and five
   bars appear.
2. **Drag and drop** — drag a file onto the panel. It should highlight, then
   preview.
3. **Paste** — copy an image to the clipboard and press `Ctrl+V` anywhere on
   the page.
4. **Wrong type** — rename `notes.txt` to `notes.jpg` and upload it. Expect
   *"The file extension says image, but the contents do not."*
5. **Too large** — upload anything over 8 MB. Expect a 413 and a clear message.
6. **Server down** — stop Flask, then click Classify. Expect *"Could not reach
   the server."*
7. **Responsive** — narrow the window below 900 px. The two panels stack.
8. **Keyboard** — `Tab` to the drop zone, press `Enter`, choose a file, `Tab`
   to Classify, press `Enter`.

---

## Using your own model

Either drop the files in by hand:

```
models/model.keras        a Keras 3 model
models/labels.txt         one class name per line, in training order
models/model.meta.json    {"preprocess": "rescale"}   (optional)
```

Or train one with transfer learning. Arrange your images like this:

```
data/train/<class>/*.jpg
data/val/<class>/*.jpg
```

then:

```bash
python scripts/train_custom_model.py --data-dir data --epochs 8
```

It writes all three files into `models/` and prints validation accuracy.
Restart the app; the header chips will show your model instead of MobileNetV2.
Delete the three files to go back to ImageNet.

---

## Configuration

Copy `.env.example` to `.env`. Everything is optional.

| Variable | Default | Meaning |
|---|---|---|
| `FLASK_ENV` | `development` | `development`, `production` or `testing` |
| `SECRET_KEY` | dev placeholder | Change this in production |
| `MAX_UPLOAD_MB` | `8` | Rejected before the body is buffered |
| `TOP_K` | `5` | Classes shown in the readout |
| `PRELOAD_MODEL` | `0` | Load at boot, not on first request |
| `KEEP_UPLOADS` | `0` | Write a copy of each upload to `uploads/` |
| `LOG_LEVEL` | `INFO` | |
| `PORT` | `5000` | |

---

## Production

Windows:

```powershell
$env:FLASK_ENV = "production"
waitress-serve --host=0.0.0.0 --port=8000 "app:create_app()"
```

Linux / macOS:

```bash
export FLASK_ENV=production
pip install gunicorn
gunicorn --workers 2 --threads 4 --timeout 120 "app:create_app()"
```

Use **threads, not processes**, to share one model. Each worker process loads
its own copy of the graph into memory.

---

## Troubleshooting

**`ERROR: Could not find a version that satisfies the requirement tensorflow`**
You are on Python 3.13, or on 32-bit Python. Check with
`python -c "import sys, platform; print(sys.version, platform.architecture())"`.
Install 64-bit Python 3.12 and recreate the venv. On 3.13 you can instead try
`pip install tensorflow==2.20.0`.

**`.\venv\Scripts\Activate.ps1 cannot be loaded because running scripts is disabled`**
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

**`ModuleNotFoundError: No module named 'flask'`**
The virtual environment is not active. The prompt must start with `(venv)`.
In VS Code, `Ctrl+Shift+P` → *Python: Select Interpreter* → the one inside
`venv`.

**`A module that was compiled using NumPy 1.x cannot be run in NumPy 2.x`**
Something upgraded NumPy. Pin it back:
```bash
pip install "numpy==1.26.4" --force-reinstall
```

**`ImportError: DLL load failed while importing _pywrap_tensorflow_internal`**
Windows is missing the Visual C++ runtime. Install the
*Microsoft Visual C++ Redistributable for Visual Studio 2015–2022 (x64)* and
reboot.

**First request hangs, then `URLError` / `Failed to download`**
Keras is fetching MobileNetV2 weights and cannot reach the network. Connect
once, or place your own model in `models/` so the download is skipped entirely.

**Console floods with `oneDNN custom operations are on…` / `TF-TRT Warning`**
Harmless. `app.py` already sets `TF_CPP_MIN_LOG_LEVEL=2`; raise it to `3` to
silence more.

**`OSError: [Errno 98] Address already in use` / `[WinError 10048]`**
Port 5000 is taken. On macOS it is usually AirPlay Receiver. Use another port:
```bash
PORT=5050 python app.py
```
```powershell
$env:PORT = "5050"; python app.py
```

**The prediction is confidently wrong**
MobileNetV2 knows 1,000 ImageNet classes and nothing else. It has no class for
"my desk" or "a screenshot", so it picks the nearest thing it does know. Train
your own model for your own categories.

**Model loads twice on startup**
That is Flask's reloader. `app.py` disables it (`use_reloader=False`) precisely
for this reason. If you run with `flask run`, pass `--no-reload`.

---

## License

MIT. Use it, ship it, put it on your CV.
