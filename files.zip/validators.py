"""Validation for incoming file uploads.

The rule here is defence in depth: check the extension (cheap), check the
declared size (cheap), then check the actual bytes (authoritative). A file
called `cat.jpg` that contains a ZIP archive never reaches the model.
"""

from __future__ import annotations

from typing import Iterable

from werkzeug.datastructures import FileStorage


class InvalidImageError(ValueError):
    """Raised when an upload is missing, too large, or not a real image."""


# Leading bytes for every format we accept. Checked against the real payload.
_MAGIC_SIGNATURES: tuple[bytes, ...] = (
    b"\xff\xd8\xff",              # JPEG
    b"\x89PNG\r\n\x1a\n",        # PNG
    b"GIF87a",                    # GIF
    b"GIF89a",                    # GIF
    b"BM",                        # BMP
)


def _is_riff_webp(head: bytes) -> bool:
    return len(head) >= 12 and head[:4] == b"RIFF" and head[8:12] == b"WEBP"


def has_allowed_extension(filename: str, allowed: Iterable[str]) -> bool:
    if not filename or "." not in filename:
        return False
    ext = filename.rsplit(".", 1)[1].strip().lower()
    return ext in set(allowed)


def looks_like_image(payload: bytes) -> bool:
    """True when the first bytes match a supported image container."""
    if len(payload) < 12:
        return False
    if _is_riff_webp(payload):
        return True
    return any(payload.startswith(sig) for sig in _MAGIC_SIGNATURES)


def read_upload(
    file_storage: FileStorage | None,
    allowed_extensions: Iterable[str],
    max_bytes: int,
) -> bytes:
    """Validate `file_storage` and return its bytes.

    Raises:
        InvalidImageError: with a message written for the end user.
    """
    if file_storage is None or not file_storage.filename:
        raise InvalidImageError("No file was attached to the request.")

    filename = file_storage.filename
    if not has_allowed_extension(filename, allowed_extensions):
        allowed = ", ".join(sorted(set(allowed_extensions)))
        raise InvalidImageError(f"Unsupported file type. Use one of: {allowed}.")

    payload = file_storage.read()
    file_storage.stream.seek(0)

    if not payload:
        raise InvalidImageError("The file is empty.")

    if len(payload) > max_bytes:
        limit_mb = max_bytes / (1024 * 1024)
        raise InvalidImageError(f"The file is larger than {limit_mb:.0f} MB.")

    if not looks_like_image(payload):
        raise InvalidImageError(
            "The file extension says image, but the contents do not. "
            "Re-export the picture and try again."
        )

    return payload
