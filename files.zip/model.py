"""Model loading.

Two paths are supported:

1. **Your own model.** Drop a Keras file at `models/model.keras` plus a
   `models/labels.txt` (one class name per line, in training order). Optional
   `models/model.meta.json` overrides the preprocessing mode.
   `scripts/train_custom_model.py` writes all three for you.

2. **No model on disk.** The app falls back to MobileNetV2 with ImageNet
   weights, so it classifies 1,000 everyday categories out of the box.

The model is loaded once per process behind a lock and reused for every
request. Keras models are not safe to load concurrently, and reloading a
150 MB graph per request would be catastrophic.
"""

from __future__ import annotations

import json
import logging
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

log = logging.getLogger(__name__)

_LOCK = threading.Lock()
_BUNDLE: "ModelBundle | None" = None


class ModelLoadError(RuntimeError):
    """Raised when neither a custom model nor the fallback can be loaded."""


@dataclass
class Prediction:
    label: str
    confidence: float

    def as_dict(self) -> dict[str, Any]:
        return {"label": self.label, "confidence": round(float(self.confidence), 6)}


@dataclass
class ModelBundle:
    """Everything the request handler needs to run one inference."""

    name: str
    source: str  # "custom" or "imagenet"
    input_size: tuple[int, int]
    preprocess_mode: str
    keras_model: Any = field(repr=False)
    labels: list[str] | None = None

    # -- inference ---------------------------------------------------------
    def predict(self, batch: np.ndarray) -> np.ndarray:
        """Return a 1-D probability vector for a single-image batch."""
        raw = self.keras_model.predict(batch, verbose=0)
        probs = np.asarray(raw, dtype=np.float32)[0]

        # A model whose last layer is `linear` emits logits, not probabilities.
        total = float(probs.sum())
        if probs.min() < 0.0 or not (0.99 <= total <= 1.01):
            probs = _softmax(probs)
        return probs

    def decode(self, probs: np.ndarray, top_k: int) -> list[Prediction]:
        top_k = max(1, min(top_k, probs.shape[0]))

        if self.source == "imagenet":
            decoded = _decode_imagenet(probs, top_k)
            if decoded is not None:
                return decoded

        indices = np.argsort(probs)[::-1][:top_k]
        return [
            Prediction(label=self._label_for(int(i)), confidence=float(probs[i]))
            for i in indices
        ]

    def _label_for(self, index: int) -> str:
        if self.labels and 0 <= index < len(self.labels):
            return self.labels[index]
        return f"class_{index}"

    def describe(self) -> dict[str, Any]:
        height, width = self.input_size
        return {
            "name": self.name,
            "source": self.source,
            "input_shape": [height, width, 3],
            "classes": len(self.labels) if self.labels else 1000,
            "preprocess": self.preprocess_mode,
        }


def _softmax(vector: np.ndarray) -> np.ndarray:
    shifted = vector - np.max(vector)
    exps = np.exp(shifted)
    return exps / np.sum(exps)


def _decode_imagenet(probs: np.ndarray, top_k: int) -> list[Prediction] | None:
    """Map ImageNet indices to human names using the Keras label map."""
    try:
        from tensorflow.keras.applications.mobilenet_v2 import decode_predictions

        decoded = decode_predictions(probs.reshape(1, -1), top=top_k)[0]
    except Exception as exc:  # noqa: BLE001 - label file may be unreachable
        log.warning("Falling back to numeric ImageNet labels: %s", exc)
        return None

    return [
        Prediction(label=name.replace("_", " "), confidence=float(score))
        for _wnid, name, score in decoded
    ]


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------
def _read_labels(path: Path) -> list[str]:
    lines = path.read_text(encoding="utf-8").splitlines()
    labels = [line.strip() for line in lines if line.strip()]
    if not labels:
        raise ModelLoadError(f"{path} contains no class names.")
    return labels


def _read_meta(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        log.warning("Ignoring unreadable %s: %s", path, exc)
        return {}


def _input_size_from(keras_model: Any, default: tuple[int, int]) -> tuple[int, int]:
    try:
        shape = keras_model.input_shape  # (None, H, W, C)
        if shape and len(shape) == 4 and shape[1] and shape[2]:
            return int(shape[1]), int(shape[2])
    except Exception:  # noqa: BLE001 - exotic model, use the configured size
        pass
    return default


def _load_custom(config: Any) -> ModelBundle:
    import tensorflow as tf

    log.info("Loading custom model from %s", config.CUSTOM_MODEL_PATH)
    keras_model = tf.keras.models.load_model(config.CUSTOM_MODEL_PATH, compile=False)
    labels = _read_labels(config.LABELS_PATH)
    meta = _read_meta(config.META_PATH)

    return ModelBundle(
        name=meta.get("name", config.CUSTOM_MODEL_PATH.stem),
        source="custom",
        input_size=_input_size_from(keras_model, tuple(config.IMAGE_SIZE)),
        preprocess_mode=meta.get("preprocess", "rescale"),
        keras_model=keras_model,
        labels=labels,
    )


def _load_fallback(config: Any) -> ModelBundle:
    import tensorflow as tf

    log.info("No custom model found. Loading %s (ImageNet).", config.FALLBACK_MODEL_NAME)
    height, width = config.IMAGE_SIZE
    keras_model = tf.keras.applications.MobileNetV2(
        weights="imagenet",
        include_top=True,
        input_shape=(height, width, 3),
    )
    return ModelBundle(
        name=config.FALLBACK_MODEL_NAME,
        source="imagenet",
        input_size=(height, width),
        preprocess_mode="mobilenet_v2",
        keras_model=keras_model,
        labels=None,
    )


def _warm_up(bundle: ModelBundle) -> None:
    """First inference builds the graph. Pay that cost at boot, not per user."""
    height, width = bundle.input_size
    dummy = np.zeros((1, height, width, 3), dtype=np.float32)
    bundle.keras_model.predict(dummy, verbose=0)


def _build(config: Any) -> ModelBundle:
    has_custom = config.CUSTOM_MODEL_PATH.exists() and config.LABELS_PATH.exists()
    try:
        bundle = _load_custom(config) if has_custom else _load_fallback(config)
    except ModelLoadError:
        raise
    except Exception as exc:  # noqa: BLE001 - surface a single actionable error
        raise ModelLoadError(
            "The model could not be loaded. If this is the first run, check that "
            "the machine can reach storage.googleapis.com to download the "
            f"MobileNetV2 weights. Original error: {exc}"
        ) from exc

    _warm_up(bundle)
    log.info("Model ready: %s", bundle.describe())
    return bundle


def get_model(config: Any) -> ModelBundle:
    """Return the process-wide model, loading it on first use."""
    global _BUNDLE
    if _BUNDLE is None:
        with _LOCK:
            if _BUNDLE is None:
                _BUNDLE = _build(config)
    return _BUNDLE


def set_model(bundle: ModelBundle | None) -> None:
    """Inject a bundle. Used by the test suite to avoid touching TensorFlow."""
    global _BUNDLE
    with _LOCK:
        _BUNDLE = bundle
