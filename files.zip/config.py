"""Application configuration.

Every value can be overridden with an environment variable, which makes the
same codebase usable in development, tests and production without edits.
Copy `.env.example` to `.env` and adjust as needed.
"""

from __future__ import annotations

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

# Load `.env` if it exists. python-dotenv is optional: the app runs without it.
try:
    from dotenv import load_dotenv

    load_dotenv(BASE_DIR / ".env")
except ImportError:  # pragma: no cover
    pass


def _env_bool(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _env_int(name: str, default: int) -> int:
    raw = os.environ.get(name)
    if raw is None or not raw.strip():
        return default
    try:
        return int(raw)
    except ValueError:
        return default


class Config:
    """Base configuration shared by every environment."""

    # --- Flask -----------------------------------------------------------
    SECRET_KEY: str = os.environ.get("SECRET_KEY", "dev-only-secret-change-me")
    JSON_SORT_KEYS: bool = False

    # --- Uploads ---------------------------------------------------------
    # Hard limit enforced by Werkzeug before the body is buffered.
    MAX_UPLOAD_MB: int = _env_int("MAX_UPLOAD_MB", 8)
    MAX_CONTENT_LENGTH: int = MAX_UPLOAD_MB * 1024 * 1024

    UPLOAD_FOLDER: Path = BASE_DIR / "uploads"
    # Uploads are processed in memory and discarded by default. Set
    # KEEP_UPLOADS=1 if you want a copy written to UPLOAD_FOLDER.
    KEEP_UPLOADS: bool = _env_bool("KEEP_UPLOADS", False)

    ALLOWED_EXTENSIONS: frozenset[str] = frozenset(
        {"png", "jpg", "jpeg", "webp", "bmp", "gif"}
    )

    # --- Model -----------------------------------------------------------
    MODEL_DIR: Path = BASE_DIR / "models"
    CUSTOM_MODEL_PATH: Path = MODEL_DIR / "model.keras"
    LABELS_PATH: Path = MODEL_DIR / "labels.txt"
    META_PATH: Path = MODEL_DIR / "model.meta.json"

    # Fallback when no custom model is present.
    FALLBACK_MODEL_NAME: str = "MobileNetV2"
    IMAGE_SIZE: tuple[int, int] = (224, 224)

    TOP_K: int = _env_int("TOP_K", 5)

    # Load and warm the model when the process boots instead of on the first
    # request. Slower start, no cold-start penalty for the first user.
    PRELOAD_MODEL: bool = _env_bool("PRELOAD_MODEL", False)

    # --- Logging ---------------------------------------------------------
    LOG_LEVEL: str = os.environ.get("LOG_LEVEL", "INFO").upper()


class DevelopmentConfig(Config):
    DEBUG = True
    TESTING = False


class ProductionConfig(Config):
    DEBUG = False
    TESTING = False
    PRELOAD_MODEL = _env_bool("PRELOAD_MODEL", True)


class TestingConfig(Config):
    DEBUG = False
    TESTING = True
    PRELOAD_MODEL = False
    KEEP_UPLOADS = False


_CONFIGS: dict[str, type[Config]] = {
    "development": DevelopmentConfig,
    "production": ProductionConfig,
    "testing": TestingConfig,
}


def get_config(name: str | None = None) -> type[Config]:
    """Return the config class for `name`, defaulting to $FLASK_ENV."""
    key = (name or os.environ.get("FLASK_ENV") or "development").strip().lower()
    return _CONFIGS.get(key, DevelopmentConfig)
