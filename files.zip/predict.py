"""Glue between an uploaded file and a ranked list of classes."""

from __future__ import annotations

import logging
import time
from typing import Any

from ml.model import get_model
from ml.preprocess import open_image, to_batch

log = logging.getLogger(__name__)


def classify(payload: bytes, config: Any) -> dict[str, Any]:
    """Run one image through the model.

    Args:
        payload: raw bytes of a validated image upload.
        config: the active Flask config object.

    Returns:
        A JSON-serialisable result with the ranked predictions, the winning
        class, and timing broken down into preprocessing and inference.

    Raises:
        InvalidImageError: the bytes are not a decodable image.
        ModelLoadError: the model is unavailable.
    """
    bundle = get_model(config)

    prep_start = time.perf_counter()
    image = open_image(payload)
    original_size = list(image.size)  # (width, height)
    batch = to_batch(image, bundle.input_size, bundle.preprocess_mode)
    preprocess_ms = (time.perf_counter() - prep_start) * 1000.0

    infer_start = time.perf_counter()
    probs = bundle.predict(batch)
    inference_ms = (time.perf_counter() - infer_start) * 1000.0

    predictions = [p.as_dict() for p in bundle.decode(probs, config.TOP_K)]
    top = predictions[0]

    log.info(
        "Classified as %s (%.1f%%) in %.0f ms",
        top["label"],
        top["confidence"] * 100,
        preprocess_ms + inference_ms,
    )

    return {
        "top": top,
        "predictions": predictions,
        "model": bundle.describe(),
        "timing": {
            "preprocess_ms": round(preprocess_ms, 1),
            "inference_ms": round(inference_ms, 1),
            "total_ms": round(preprocess_ms + inference_ms, 1),
        },
        "image": {"original_size": original_size},
    }
