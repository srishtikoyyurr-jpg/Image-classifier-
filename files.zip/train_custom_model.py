"""Train a custom classifier that this app will pick up automatically.

Point it at a folder of labelled images:

    data/
      train/
        cats/ img1.jpg img2.jpg ...
        dogs/ img1.jpg ...
      val/
        cats/ ...
        dogs/ ...

Then run, from the project root:

    python scripts/train_custom_model.py --data-dir data --epochs 8

It writes three files into `models/`:

    model.keras        the trained network
    labels.txt         class names, one per line, in training order
    model.meta.json    tells the app how to preprocess input for this model

On the next start, `ml/model.py` finds them and stops using MobileNetV2's
ImageNet head. Delete the three files to go back to the default.

The approach is transfer learning: freeze a MobileNetV2 backbone pretrained
on ImageNet, train a small head on top. This converges in minutes on CPU and
needs only a few hundred images per class.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

MODEL_DIR = PROJECT_ROOT / "models"
IMAGE_SIZE = (224, 224)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Fine-tune MobileNetV2 on your own images.")
    parser.add_argument("--data-dir", type=Path, default=PROJECT_ROOT / "data",
                        help="Folder containing train/ and val/ subfolders.")
    parser.add_argument("--epochs", type=int, default=8)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--learning-rate", type=float, default=1e-3)
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def build_datasets(data_dir: Path, batch_size: int, seed: int):
    import tensorflow as tf

    train_dir, val_dir = data_dir / "train", data_dir / "val"
    for path in (train_dir, val_dir):
        if not path.is_dir():
            raise SystemExit(f"Missing folder: {path}. See the docstring for the expected layout.")

    train_ds = tf.keras.utils.image_dataset_from_directory(
        train_dir, image_size=IMAGE_SIZE, batch_size=batch_size,
        label_mode="categorical", shuffle=True, seed=seed,
    )
    val_ds = tf.keras.utils.image_dataset_from_directory(
        val_dir, image_size=IMAGE_SIZE, batch_size=batch_size,
        label_mode="categorical", shuffle=False,
    )

    class_names = list(train_ds.class_names)
    autotune = tf.data.AUTOTUNE
    return (
        train_ds.cache().prefetch(autotune),
        val_ds.cache().prefetch(autotune),
        class_names,
    )


def build_model(num_classes: int, learning_rate: float):
    import tensorflow as tf
    from tensorflow.keras import layers

    # The app sends pixels in [0, 1] ("rescale" mode); shift them to [-1, 1]
    # here so the backbone sees exactly what it was pretrained on.
    inputs = layers.Input(shape=(*IMAGE_SIZE, 3), name="image")
    x = layers.Rescaling(scale=2.0, offset=-1.0)(inputs)

    x = layers.RandomFlip("horizontal")(x)
    x = layers.RandomRotation(0.05)(x)
    x = layers.RandomZoom(0.1)(x)

    backbone = tf.keras.applications.MobileNetV2(
        input_shape=(*IMAGE_SIZE, 3), include_top=False, weights="imagenet"
    )
    backbone.trainable = False

    x = backbone(x, training=False)
    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dropout(0.2)(x)
    outputs = layers.Dense(num_classes, activation="softmax", name="probabilities")(x)

    model = tf.keras.Model(inputs, outputs, name="custom_classifier")
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate),
        loss="categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


def main() -> None:
    import tensorflow as tf

    args = parse_args()
    tf.keras.utils.set_random_seed(args.seed)

    train_ds, val_ds, class_names = build_datasets(args.data_dir, args.batch_size, args.seed)
    print(f"Classes ({len(class_names)}): {', '.join(class_names)}")

    model = build_model(len(class_names), args.learning_rate)
    model.summary()

    MODEL_DIR.mkdir(parents=True, exist_ok=True)

    model.fit(
        train_ds,
        validation_data=val_ds,
        epochs=args.epochs,
        callbacks=[
            tf.keras.callbacks.EarlyStopping(
                monitor="val_accuracy", patience=3, restore_best_weights=True
            ),
            tf.keras.callbacks.ModelCheckpoint(
                MODEL_DIR / "model.keras", monitor="val_accuracy", save_best_only=True
            ),
        ],
    )

    loss, accuracy = model.evaluate(val_ds, verbose=0)
    print(f"Validation loss {loss:.4f} · accuracy {accuracy:.4f}")

    (MODEL_DIR / "labels.txt").write_text("\n".join(class_names) + "\n", encoding="utf-8")
    (MODEL_DIR / "model.meta.json").write_text(
        json.dumps(
            {
                "name": "custom_classifier",
                "preprocess": "rescale",
                "input_size": list(IMAGE_SIZE),
                "val_accuracy": round(float(accuracy), 4),
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    print(f"Saved model.keras, labels.txt and model.meta.json to {MODEL_DIR}")
    print("Restart the Flask app to use it.")


if __name__ == "__main__":
    main()
