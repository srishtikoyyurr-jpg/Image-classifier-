/* =========================================================================
   Image Classifier — client
   Handles selection, preview, validation, the request, and the readout.
   No framework, no build step: this file is the whole client.
   ========================================================================= */

(() => {
  "use strict";

  const REQUEST_TIMEOUT_MS = 60_000;

  // --- element handles ---------------------------------------------------
  const dropzone     = document.getElementById("dropzone");
  const fileInput    = document.getElementById("file-input");
  const previewWrap  = document.getElementById("preview-wrap");
  const previewImg   = document.getElementById("preview-img");
  const classifyBtn  = document.getElementById("classify-btn");
  const clearBtn     = document.getElementById("clear-btn");

  const readoutIdle    = document.getElementById("readout-idle");
  const readoutBody    = document.getElementById("readout-body");
  const readoutError   = document.getElementById("readout-error");
  const readoutLoading = document.getElementById("readout-loading");
  const readoutRegion  = document.getElementById("readout");

  const errorMessage = document.getElementById("error-message");
  const verdictLabel = document.getElementById("verdict-label");
  const verdictScore = document.getElementById("verdict-score");
  const distList     = document.getElementById("dist");
  const timingNote   = document.querySelector("[data-timing]");
  const metaName     = document.querySelector('[data-meta="filename"]');
  const metaDims     = document.querySelector('[data-meta="dims"]');

  if (!dropzone || !fileInput) return; // not on the classifier page

  // --- limits, read from the server-rendered markup ----------------------
  const MAX_BYTES = Number(dropzone.dataset.maxMb || 8) * 1024 * 1024;
  const ALLOWED_EXTENSIONS = (fileInput.getAttribute("accept") || "")
    .split(",")
    .map((token) => token.trim().replace(/^\./, "").toLowerCase())
    .filter(Boolean);

  // --- state -------------------------------------------------------------
  let selectedFile = null;
  let objectUrl = null;
  let inFlight = null;

  // --- helpers -----------------------------------------------------------
  const show = (el) => el && el.removeAttribute("hidden");
  const hide = (el) => el && el.setAttribute("hidden", "");

  const formatBytes = (bytes) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const extensionOf = (name) => {
    const parts = String(name).toLowerCase().split(".");
    return parts.length > 1 ? parts.pop() : "";
  };

  function validate(file) {
    if (!file) return "No file was selected.";
    if (!ALLOWED_EXTENSIONS.includes(extensionOf(file.name))) {
      return `Unsupported file type. Use one of: ${ALLOWED_EXTENSIONS.join(", ")}.`;
    }
    if (file.size === 0) return "The file is empty.";
    if (file.size > MAX_BYTES) {
      return `The file is ${formatBytes(file.size)}. The limit is ${formatBytes(MAX_BYTES)}.`;
    }
    return null;
  }

  // --- readout states ----------------------------------------------------
  function showIdle() {
    hide(readoutError);
    hide(readoutBody);
    hide(readoutLoading);
    hide(timingNote);
    show(readoutIdle);
    readoutRegion.setAttribute("aria-busy", "false");
  }

  function showError(message) {
    errorMessage.textContent = message;
    hide(readoutIdle);
    hide(readoutBody);
    hide(readoutLoading);
    hide(timingNote);
    show(readoutError);
    readoutRegion.setAttribute("aria-busy", "false");
  }

  function showLoading() {
    hide(readoutIdle);
    hide(readoutError);
    hide(readoutBody);
    hide(timingNote);
    show(readoutLoading);
    readoutRegion.setAttribute("aria-busy", "true");
  }

  function setBusy(busy) {
    classifyBtn.disabled = busy || !selectedFile;
    classifyBtn.dataset.busy = busy ? "true" : "false";
    classifyBtn.querySelector(".primary__label").textContent = busy
      ? "Classifying…"
      : "Classify image";
    dropzone.dataset.state = busy ? "busy" : selectedFile ? "loaded" : "empty";
  }

  // --- rendering ---------------------------------------------------------
  function renderResult(data) {
    const { top, predictions, timing } = data;

    verdictLabel.textContent = top.label;
    verdictScore.textContent = (top.confidence * 100).toFixed(1);

    distList.replaceChildren();
    predictions.forEach((prediction, index) => {
      const percent = prediction.confidence * 100;

      const row = document.createElement("li");
      row.className = "dist__row" + (index === 0 ? " dist__row--top" : "");

      const meta = document.createElement("div");
      meta.className = "dist__meta";

      const name = document.createElement("span");
      name.className = "dist__name";
      name.textContent = prediction.label;

      const value = document.createElement("span");
      value.className = "dist__value";
      value.textContent = `${percent.toFixed(2)}%`;

      meta.append(name, value);

      const track = document.createElement("div");
      track.className = "dist__track";

      const bar = document.createElement("div");
      bar.className = "dist__bar";
      track.append(bar);

      row.append(meta, track);
      distList.append(row);

      // Next frame, so the width transition actually runs.
      requestAnimationFrame(() => {
        bar.style.width = `${Math.max(percent, 0.4)}%`;
      });
    });

    if (timing) {
      timingNote.textContent =
        `prep ${timing.preprocess_ms} ms · infer ${timing.inference_ms} ms`;
      show(timingNote);
    }

    hide(readoutIdle);
    hide(readoutError);
    hide(readoutLoading);
    show(readoutBody);
    readoutRegion.setAttribute("aria-busy", "false");
  }

  // --- file selection ----------------------------------------------------
  function acceptFile(file) {
    const problem = validate(file);
    if (problem) {
      clearSelection();
      showError(problem);
      return;
    }

    selectedFile = file;

    if (objectUrl) URL.revokeObjectURL(objectUrl);
    objectUrl = URL.createObjectURL(file);

    previewImg.onload = () => {
      metaDims.textContent =
        `${previewImg.naturalWidth}×${previewImg.naturalHeight} · ${formatBytes(file.size)}`;
    };
    previewImg.onerror = () => {
      clearSelection();
      showError("That image could not be displayed. It may be corrupt.");
    };
    previewImg.src = objectUrl;
    previewImg.alt = `Preview of ${file.name}`;

    metaName.textContent = file.name;
    metaDims.textContent = formatBytes(file.size);

    show(previewWrap);
    dropzone.dataset.state = "loaded";
    show(clearBtn);
    classifyBtn.disabled = false;
    showIdle();
  }

  function clearSelection() {
    if (inFlight) inFlight.abort();
    selectedFile = null;

    if (objectUrl) {
      URL.revokeObjectURL(objectUrl);
      objectUrl = null;
    }

    previewImg.removeAttribute("src");
    fileInput.value = "";
    hide(previewWrap);
    hide(clearBtn);
    dropzone.dataset.state = "empty";
    classifyBtn.disabled = true;
    setBusy(false);
  }

  // --- request -----------------------------------------------------------
  async function classify() {
    if (!selectedFile) return;

    const controller = new AbortController();
    inFlight = controller;
    const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

    setBusy(true);
    showLoading();

    const body = new FormData();
    body.append("image", selectedFile, selectedFile.name);

    try {
      const response = await fetch("/api/predict", {
        method: "POST",
        body,
        signal: controller.signal,
        headers: { Accept: "application/json" },
      });

      let payload;
      try {
        payload = await response.json();
      } catch {
        throw new Error(`The server returned an unreadable response (HTTP ${response.status}).`);
      }

      if (!response.ok || !payload.ok) {
        throw new Error(payload?.error?.message || `Request failed with HTTP ${response.status}.`);
      }

      renderResult(payload);
    } catch (error) {
      if (error.name === "AbortError") {
        showError("The request took too long and was cancelled. Try a smaller image.");
      } else if (error instanceof TypeError) {
        showError("Could not reach the server. Check that the Flask app is still running.");
      } else {
        showError(error.message);
      }
    } finally {
      clearTimeout(timer);
      inFlight = null;
      setBusy(false);
    }
  }

  // --- model chips -------------------------------------------------------
  async function loadModelInfo() {
    const targets = {
      name: document.querySelector('[data-model="name"]'),
      shape: document.querySelector('[data-model="shape"]'),
      classes: document.querySelector('[data-model="classes"]'),
    };
    if (!targets.name) return;

    try {
      const response = await fetch("/api/model", { headers: { Accept: "application/json" } });
      const payload = await response.json();
      if (!payload.ok) throw new Error("unavailable");

      const { name, input_shape: shape, classes } = payload.model;
      targets.name.textContent = name;
      targets.shape.textContent = shape.join("×");
      targets.classes.textContent = String(classes);
    } catch {
      Object.values(targets).forEach((el) => {
        el.textContent = "offline";
      });
    }
  }

  // --- events ------------------------------------------------------------
  fileInput.addEventListener("change", (event) => {
    const [file] = event.target.files || [];
    if (file) acceptFile(file);
  });

  ["dragenter", "dragover"].forEach((type) => {
    dropzone.addEventListener(type, (event) => {
      event.preventDefault();
      if (!selectedFile) dropzone.dataset.state = "dragging";
    });
  });

  ["dragleave", "drop"].forEach((type) => {
    dropzone.addEventListener(type, (event) => {
      event.preventDefault();
      if (type === "dragleave" && dropzone.contains(event.relatedTarget)) return;
      dropzone.dataset.state = selectedFile ? "loaded" : "empty";
    });
  });

  dropzone.addEventListener("drop", (event) => {
    const file = event.dataTransfer?.files?.[0];
    if (file) acceptFile(file);
  });

  document.addEventListener("paste", (event) => {
    const item = [...(event.clipboardData?.items || [])].find((i) => i.type.startsWith("image/"));
    if (!item) return;
    const file = item.getAsFile();
    if (file) acceptFile(file);
  });

  classifyBtn.addEventListener("click", classify);
  clearBtn.addEventListener("click", () => {
    clearSelection();
    showIdle();
  });

  window.addEventListener("beforeunload", () => {
    if (objectUrl) URL.revokeObjectURL(objectUrl);
  });

  // --- boot --------------------------------------------------------------
  showIdle();
  loadModelInfo();
})();
